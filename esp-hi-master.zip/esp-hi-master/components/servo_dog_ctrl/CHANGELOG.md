# ChangeLog

## v0.1.2 - 2025-05-28

* Change SERVO_DOG_ACTION_TABLE description

## v0.1.0 - 2025-05-26

* Add readme.md

## v0.1.0 - 2025-05-22

* publish official version
